from django.contrib import admin
from .models import Book, WishList, BookItem

admin.site.register(Book)
admin.site.register(WishList)
admin.site.register(BookItem)
