"""geektext1 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from EmployeeApp.views import book_list, book_detail, wishlist_list, wishlist_detail, bookitem_list, bookitem_detail
from rest_framework.urlpatterns import format_suffix_patterns
from EmployeeApp.views import add_book_to_wishlist, remove_book_from_wishlist, wishlist_books
from EmployeeApp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('books/', book_list),
    path('books/<int:pk>/', book_detail),
    path('wishlists/', wishlist_list),
    path('wishlists/<int:pk>/', wishlist_detail),
    path('bookitems/', bookitem_list),
    path('bookitems/<int:pk>/', bookitem_detail),
    path('wishlists/<int:wishlist_id>/add_book/<int:book_id>/', add_book_to_wishlist),
    path('wishlist/<int:wishlist_id>/remove_book/<int:book_id>/', remove_book_from_wishlist, name='remove_book_from_wishlist'),
    path('wishlists/<int:wishlist_id>/books/', views.wishlist_books, name='wishlist_books'),
]

urlpatterns = format_suffix_patterns(urlpatterns)



