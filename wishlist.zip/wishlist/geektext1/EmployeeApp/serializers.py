from rest_framework import serializers
from .models import Book, WishList, BookItem

class BookSerializer(serializers.ModelSerializer):
    class Meta:
        model = Book
        fields = ['title', 'author', 'description', 'publication_date', 'isbn']

class WishListSerializer(serializers.ModelSerializer):

    class Meta:
        model = WishList
        fields = ['user', 'name', 'book']

class BookItemSerializer(serializers.ModelSerializer):

    class Meta:
        model = BookItem
        fields = ['book', 'wishlist']
