from rest_framework import generics
from .models import Book, WishList, BookItem
from .serializers import BookSerializer, WishListSerializer, BookItemSerializer

class BookList(generics.ListCreateAPIView):
    queryset = Book.objects.all()
    serializer_class = BookSerializer

class BookDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = Book.objects.all()
    serializer_class = BookSerializer

class WishListList(generics.ListCreateAPIView):
    queryset = WishList.objects.all()
    serializer_class = WishListSerializer

class WishListDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = WishList.objects.all()
    serializer_class = WishListSerializer

class BookItemList(generics.ListCreateAPIView):
    queryset = BookItem.objects.all()
    serializer_class = BookItemSerializer

class BookItemDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = BookItem.objects.all()
    serializer_class = BookItemSerializer
